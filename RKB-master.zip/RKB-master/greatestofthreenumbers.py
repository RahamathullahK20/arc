a=int(raw_input("Enter the number A"))
b=int(raw_input("Enter the number B"))
c=int(raw_input("Enter the number C"))
if(a>=b)and(a>c):
    print(a)
elif(b>=a)and(b>c):
    print(b)
else:
    print(c)
