x=str(raw_input("Enter the letter"))
if x in('b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','x','z','a','e','i','o','u'):
    print("Alphabet")
else:
    print("No")
