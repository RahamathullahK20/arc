n=int(input("Input:"))
i=0
print("Output:")
while i<n:
  print("Hello")
  i=i+1
