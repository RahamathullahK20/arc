x=int(raw_input("Enter the year"))
if(x%4==0):
    print("YES")
else:
    print("NO")
