def main():
    x=int(raw_input("Enter the number"))
    if(x>0):
	print("positive")
    elif(x<0):
	print("Negative")
    else:
	print("Zero")

if __name__ == '__main__':
    main()
